import { Competencia } from './competencia.model';

describe('Competencia', () => {
  it('should create an instance', () => {
    expect(new Competencia()).toBeTruthy();
  });
});
