import { Coordenador } from './coordenador.model';

describe('Coordenador', () => {
  it('should create an instance', () => {
    expect(new Coordenador()).toBeTruthy();
  });
});
