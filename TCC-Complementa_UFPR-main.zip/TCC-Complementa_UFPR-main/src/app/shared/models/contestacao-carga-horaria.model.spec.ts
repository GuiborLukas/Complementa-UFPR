import { ContestacaoCargaHoraria } from './contestacao-carga-horaria.model';

describe('ContestacaoCargaHoraria', () => {
  it('should create an instance', () => {
    expect(new ContestacaoCargaHoraria()).toBeTruthy();
  });
});
