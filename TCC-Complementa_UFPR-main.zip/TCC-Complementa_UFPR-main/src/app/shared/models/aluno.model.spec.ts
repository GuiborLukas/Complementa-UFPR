import { Aluno } from './aluno.model';

describe('Aluno', () => {
  it('should create an instance', () => {
    expect(new Aluno()).toBeTruthy();
  });
});
