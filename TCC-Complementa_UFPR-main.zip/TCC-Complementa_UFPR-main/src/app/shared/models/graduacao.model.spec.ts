import { Graduacao } from './graduacao.model';

describe('Graduacao', () => {
  it('should create an instance', () => {
    expect(new Graduacao()).toBeTruthy();
  });
});
