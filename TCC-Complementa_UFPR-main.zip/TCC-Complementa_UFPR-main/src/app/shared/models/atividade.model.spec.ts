import { Atividade } from './atividade.model';

describe('Atividade', () => {
  it('should create an instance', () => {
    expect(new Atividade()).toBeTruthy();
  });
});
