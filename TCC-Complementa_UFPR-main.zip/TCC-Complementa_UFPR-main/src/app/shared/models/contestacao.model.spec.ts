import { Contestacao } from './contestacao.model';

describe('Contestacao', () => {
  it('should create an instance', () => {
    expect(new Contestacao()).toBeTruthy();
  });
});
