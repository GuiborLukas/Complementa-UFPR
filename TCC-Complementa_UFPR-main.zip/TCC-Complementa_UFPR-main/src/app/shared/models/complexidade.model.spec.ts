import { Complexidade } from './complexidade.model';

describe('Complexidade', () => {
  it('should create an instance', () => {
    expect(new Complexidade()).toBeTruthy();
  });
});
