import { RelatorioDeConclusao } from './relatorio-de-conclusao.model';

describe('RelatorioDeConclusao', () => {
  it('should create an instance', () => {
    expect(new RelatorioDeConclusao()).toBeTruthy();
  });
});
