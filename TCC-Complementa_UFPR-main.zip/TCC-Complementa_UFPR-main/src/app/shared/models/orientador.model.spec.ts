import { Orientador } from './orientador.model';

describe('Orientador', () => {
  it('should create an instance', () => {
    expect(new Orientador()).toBeTruthy();
  });
});
