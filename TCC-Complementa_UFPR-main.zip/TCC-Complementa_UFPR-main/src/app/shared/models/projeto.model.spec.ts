import { Projeto } from './projeto.model';

describe('Projeto', () => {
  it('should create an instance', () => {
    expect(new Projeto()).toBeTruthy();
  });
});
