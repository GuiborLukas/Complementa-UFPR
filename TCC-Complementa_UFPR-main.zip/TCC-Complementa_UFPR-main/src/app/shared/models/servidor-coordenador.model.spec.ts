import { ServidorCoordenador } from './servidor-coordenador.model';

describe('ServidorCoordenador', () => {
  it('should create an instance', () => {
    expect(new ServidorCoordenador()).toBeTruthy();
  });
});
