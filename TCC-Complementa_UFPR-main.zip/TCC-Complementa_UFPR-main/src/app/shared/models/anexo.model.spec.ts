import { Anexo } from './anexo.model';

describe('Anexo', () => {
  it('should create an instance', () => {
    expect(new Anexo()).toBeTruthy();
  });
});
