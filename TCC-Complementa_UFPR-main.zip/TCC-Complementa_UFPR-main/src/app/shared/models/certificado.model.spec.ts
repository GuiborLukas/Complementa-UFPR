import { Certificado } from './certificado.model';

describe('Certificado', () => {
  it('should create an instance', () => {
    expect(new Certificado()).toBeTruthy();
  });
});
