import { Comentario } from './comentario.model';

describe('Comentario', () => {
  it('should create an instance', () => {
    expect(new Comentario()).toBeTruthy();
  });
});
