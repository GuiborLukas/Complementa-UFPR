import { Servidor } from './servidor.model';

describe('Servidor', () => {
  it('should create an instance', () => {
    expect(new Servidor()).toBeTruthy();
  });
});
