import { Monitor } from './monitor.model';

describe('Monitor', () => {
  it('should create an instance', () => {
    expect(new Monitor()).toBeTruthy();
  });
});
