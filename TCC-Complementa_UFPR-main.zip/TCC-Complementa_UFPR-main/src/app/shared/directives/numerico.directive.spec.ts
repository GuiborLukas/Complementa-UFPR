import { NumericoDirective } from './numerico.directive';

describe('NumericoDirective', () => {
  it('should create an instance', () => {
    const directive = new NumericoDirective();
    expect(directive).toBeTruthy();
  });
});
