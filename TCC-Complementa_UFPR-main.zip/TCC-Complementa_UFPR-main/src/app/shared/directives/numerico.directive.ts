import { Directive } from '@angular/core';

@Directive({
  selector: '[appNumerico]'
})
export class NumericoDirective {

  constructor() { }

}
