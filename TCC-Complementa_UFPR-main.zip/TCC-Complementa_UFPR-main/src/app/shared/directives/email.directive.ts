import { Directive } from '@angular/core';

@Directive({
  selector: '[appEmail]'
})
export class EmailDirective {

  constructor() { }

}
