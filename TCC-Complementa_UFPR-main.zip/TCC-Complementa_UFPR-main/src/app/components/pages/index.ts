export * from './pages.module';
export * from './atividades/atividades.component';
export * from './complexidades/complexidades.component';
export * from './contestacoes/contestacoes.component';
export * from './dashboard/dashboard.component';
export * from './graduacoes/graduacoes.component';
export * from './meu-perfil/meu-perfil.component';
export * from './projetos/projetos.component';
export * from './servidores/servidores.component';
export * from './competencias/competencias.component';
export * from './autocadastro/autocadastro.component';
export * from './editar-aluno/editar-aluno.component';
export * from './cadastro-de-usuarios/cadastro-de-usuarios.component';
export * from './confirmacao/confirmacao.component';
export * from './editar-usuarios/editar-usuarios.component';
export * from './valida-certificado/valida-certificado.component';

